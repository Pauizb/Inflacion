#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <array>
#include <omp.h>
#include <chrono>
//******lo mismo esta mejor coemntado en el programa MPI este igual comenta****
//*****Nicolas (comentar MPI), Paula, Mati
//vectores se parte para obtener datos elementos
std::vector<std::string> dividirCadena(const std::string& cadena, char delimitador) {
    std::vector<std::string> elementos;
    std::string elemento;
    std::istringstream flujoCadena(cadena);
    while (std::getline(flujoCadena, elemento, delimitador)) {
        elementos.push_back(elemento);
    }
    return elementos;
}

int main() {
    auto inicioSecuencial = std::chrono::high_resolution_clock::now(); // iniciamos cronometro
    std::ifstream archivo("/srv/utem/supermercado.csv");
    if (!archivo.is_open()) {
        std::cout << "No se puede abrir el archivo" << std::endl;
        return 1;
    }

    std::string linea;
    std::getline(archivo, linea); // Saltarse la primera línea

    std::array<long long, 12> totalMensualMonto{};
    std::array<long long, 12> totalMensualDescuento{}; // todas las variables array que ocuoparemos para poner los totales
    std::array<long double, 12> totalMensualFinal{};
    std::array<long double, 12> IPCMensual{};
    std::array<long double, 12> tasaInflacion{};
    long double inflacionAcumulada = 0.0000;// obetener los 4 decimales finales

    while (std::getline(archivo, linea)) {
        std::vector<std::string> valores = dividirCadena(linea, ';');
        if (valores.size() < 6) {
            continue;
        }

        std::string columnaEstado = valores[5].substr(1, valores[5].size() - 2); // Extraer el estado de la columna ESTADO

        if (columnaEstado.find("FINALIZED") != std::string::npos || columnaEstado.find("AUTHORIZED") != std::string::npos) {
            std::string fecha = valores[4].substr(1, valores[4].size() - 2); // Extraer la fecha
            std::vector<std::string> partesFecha = dividirCadena(fecha, 'T');
            std::vector<std::string> partesFechaNum = dividirCadena(partesFecha[0], '-'); // lo hizo el mati y solo ocupa los aurotizados y finalizados

            if (partesFechaNum.size() < 2) {
                std::cerr << "Formato de fecha no válido: " << fecha << '\n';
                continue;
            }

            int mes = 0;
            try {
                mes = std::stoi(partesFechaNum[1]) - 1;
            } catch (const std::invalid_argument& e) {
                std::cerr << "Mes no válido en la fecha: " << fecha << '\n';
                continue;
            }

            std::string montoStr = valores[2].substr(1, valores[2].size() - 2); // cadenas de monto y descuento
            std::string descuentoStr = valores[3].substr(1, valores[3].size() - 2);

            try {
                long long monto = std::stoll(montoStr);
                long long descuento = std::stoll(descuentoStr);
                totalMensualMonto[mes] += monto;
                totalMensualDescuento[mes] += descuento;
            } catch (const std::invalid_argument& e) {
                std::cerr << "valor no que no es numero encontrado en las columnas MONTO o DESCUENTO\n";
                continue;
            } catch (const std::out_of_range& e) {
                std::cerr << "Número demasiado grande encontrado en las columnas MONTO o DESCUENTO\n";
                continue;
            }
        }
    }
    archivo.close(); // cerramos el archivo

#pragma omp parallel for // iniciamos paralelizacione en el for
    for (int i = 0; i < 12; ++i) {
        totalMensualFinal[i] = totalMensualMonto[i] + totalMensualDescuento[i] ; // calculamos los totales por cada mes para calcular el ipc
        IPCMensual[i]= (totalMensualFinal[i] / totalMensualFinal[0])*100;
    }

    for (int j = 1; j < 12; ++j) {
        tasaInflacion[j]= ((IPCMensual[j]-IPCMensual[j-1])/IPCMensual[j-1])*100;
        inflacionAcumulada=inflacionAcumulada+tasaInflacion[j];
    }
    #pragma omp critical// se detiene la paralelizacion
    std::cout << "La inflacion acumulada es: " << inflacionAcumulada << "% " << std::endl;

    auto terminoSecuencial = std::chrono::high_resolution_clock::now();// final del cronometro
    std::chrono::duration<double, std::milli> duracionSecuencial = terminoSecuencial - inicioSecuencial;
    std::cout << "Duración OpenMP: " << duracionSecuencial.count() << " milisegundos" << std::endl;

    return 0;
}
