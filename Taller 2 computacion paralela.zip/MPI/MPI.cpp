#include <iostream>
#include <fstream> // para leer y escribir archivos.
#include <string>
#include <vector>
#include <sstream>
#include <array>
#include <mpi.h> // para MPI
#include <chrono> //funcion de tiempo en ms

//toma la cadena y el limitador en este caso ; parea devolver el vector con los datos queridos
std::vector<std::string> partirCadena(const std::string& cadena, char delimitador) {
    std::vector<std::string> datos;
    std::string dato;
    std::istringstream flujoCadena(cadena);
    while (std::getline(flujoCadena, dato, delimitador)) {
        datos.push_back(dato);
    }
    return datos;
}

int main(int argc, char** argv) {

    auto inicioSeq = std::chrono::high_resolution_clock::now(); // inicio del cronometro
    MPI_Init(&argc, &argv); //se inicializa el MPI

    int rango, numeroProcesos; // rango de los procesos a usar en MPI
    MPI_Comm_rank(MPI_COMM_WORLD, &rango);
    MPI_Comm_size(MPI_COMM_WORLD, &numeroProcesos);

    //todos los array q vamos a ocupar en los calculos del ipc con los datos
    std::array<long long, 12> totalMensualMonto{};
    std::array<long long, 12> totalMensualDescuento{};
    std::array<long double, 12> totalMensualFinal{};
    std::array<long double, 12> IPCmensual{};
    std::array<long double, 12> TasaInflacion{};
    long double InflacionAcumulada = 0.0000;
    long double InflacionAcumuladaTotal = 0.0000;

    std::string linea;
    if (rango == 0) {
    std::ifstream archivo("/srv/utem/supermercado.csv"); //se lee el archivo del profe desde la ruta dada
    if (!archivo.is_open()) {
        std::cout << "No se puede abrir el archivo" << std::endl;
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    // saltarse la primera línea importante por los nombres de las column
    std::getline(archivo, linea);
    //se recorre
    int conteoLineas = 0;
    while (std::getline(archivo, linea)) {
        if (conteoLineas % numeroProcesos == rango) {
            std::vector<std::string> valores = partirCadena(linea, ';');
            //aqui se ignora la linea que no tenga el formato estandar
            if (valores.size() < 6) {
                continue;
            }

            // extraer el estado de la columna ESTADO
            std::string columnaEstado = valores[5].substr(1, valores[5].size() - 2);

            //para verificar si el estado es "FINALIZED" o "AUTHORIZED"
            if (columnaEstado.find("FINALIZED") != std::string::npos || columnaEstado.find("AUTHORIZED") != std::string::npos) {
                // Extraer la fecha
                std::string fecha = valores[4].substr(1, valores[4].size() - 2);
                std::vector<std::string> partesFecha = partirCadena(fecha, 'T');
                std::vector<std::string> partesDate = partirCadena(partesFecha[0], '-');

                if (partesDate.size() < 2) {
                    std::cerr << "Formato de fecha no válido: " << fecha << '\n';
                    continue;
                }

                int mes = 0;
                try {
                    mes = std::stoi(partesDate[1]) - 1;
                } catch (const std::invalid_argument& e) {
                    std::cerr << "Mes no válido en la fecha: " << fecha << '\n';
                    continue;
                }


                std::string strMonto = valores[2].substr(1, valores[2].size() - 2);
                std::string strDescuento = valores[3].substr(1, valores[3].size() - 2);

                // se transofrman los monto y descuento a números y se suman a los totales
                try {
                    long long monto = std::stoll(strMonto);
                    long long descuento = std::stoll(strDescuento);
                    totalMensualMonto[mes] += monto;
                    totalMensualDescuento[mes] += descuento;
                } catch (const std::invalid_argument& e) {
                    std::cerr << "valor no que no es numero encontrado en las columnas MONTO o DESCUENTO\n"; //ver errores
                    continue;
                } catch (const std::out_of_range& e) {
                    std::cerr << "numero demasiado grande encontrado en las columnas MONTO o DESCUENTO\n";// lo mismo
                    continue;
                }
            }
        }
        conteoLineas++;
    }

    archivo.close();//cerramos el archivo
}

    MPI_Barrier(MPI_COMM_WORLD);

  //ahora a calcular el ipc segun el video que el profe mando
    if (rango == 0) {
        for (int i = 0; i < 12; ++i) {
            totalMensualFinal[i] = totalMensualMonto[i] + totalMensualDescuento[i];
            IPCmensual[i]= (totalMensualFinal[i] / totalMensualFinal[0])*100;
        }

        for (int j = 1; j < 12; ++j) {
            TasaInflacion[j]= ((IPCmensual[j]-IPCmensual[j-1])/IPCmensual[j-1])*100;
            InflacionAcumulada=InflacionAcumulada+TasaInflacion[j];// inflacion acumulada suma de todas
        }
    }

    MPI_Reduce(&InflacionAcumulada, &InflacionAcumuladaTotal, 1, MPI_LONG_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rango == 0) {
        std::cout << "La inflacion acumulada es: " << InflacionAcumuladaTotal << "% " << std::endl;
    }

    MPI_Finalize();
    auto terminoSeq = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> duracionSeq = terminoSeq - inicioSeq; //termino del tiempo cronometrado
    std::cout << "Duración MPI: " << duracionSeq.count() << " milisegundos" << std::endl;
    return 0;
}
